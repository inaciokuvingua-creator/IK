import { useState, useEffect } from 'react';
import {
  Vault, Wallet, Briefcase, Building2, ShoppingBag, Bot, Users,
  ChevronLeft, ChevronRight, Play, Pause, Sparkles, TrendingUp,
  Target, ShieldCheck, ArrowUpRight, BarChart2, Layers
} from 'lucide-react';

export type SlideItem = {
  id: string;
  tag: string;
  title: string;
  subtitle: string;
  description: string;
  icon: typeof Vault;
  accentColor: string; // e.g. emerald, blue, amber, purple, cyan
  bgGradient: string;
  stats: { label: string; value: string; badge?: string }[];
  features: string[];
  previewType: 'cofres' | 'financeiro' | 'negocios' | 'patrimonio' | 'marketplace' | 'ai' | 'comunidade';
};

const SLIDES: SlideItem[] = [
  {
    id: 'cofres',
    tag: 'Poupança & Objetivos',
    title: 'Cofres Inteligentes',
    subtitle: 'Planeie metas com cotações e simulador de custos real',
    description: 'Crie cofres direcionados para compras, emergências ou projetos. Adicione itens com preços pesquisados, simule o tempo para atingir o objetivo e monitorize o progresso.',
    icon: Vault,
    accentColor: 'emerald',
    bgGradient: 'from-emerald-950/60 via-gray-900/60 to-gray-950/60',
    stats: [
      { label: 'Metas Concluídas', value: '84%', badge: '+12% este mês' },
      { label: 'Moeda Base', value: 'Kwanza (AOA)' },
      { label: 'Simulador IA', value: 'Ativo' },
    ],
    features: ['Calculadora de inflação', 'Múltiplas cotações por item', 'Simulação em AOA/USD/EUR'],
    previewType: 'cofres',
  },
  {
    id: 'financeiro',
    tag: 'Gestão Financeira',
    title: 'Dashboard & Transações',
    subtitle: 'Controlo total de fluxo de caixa e saldos em tempo real',
    description: 'Registe receitas, despesas e transferências. Visualize o seu saldo consolidado em tempo real com categorização automática e relatórios visuais intuitivos.',
    icon: Wallet,
    accentColor: 'teal',
    bgGradient: 'from-teal-950/60 via-gray-900/60 to-gray-950/60',
    stats: [
      { label: 'Saldo Atual', value: '2.450.000 KZ', badge: 'Positivo' },
      { label: 'Poupança Mensal', value: '35%' },
      { label: 'Categorias', value: '18 ativas' },
    ],
    features: ['Categorização inteligente', 'Suporte a múltiplas moedas', 'Gráficos interativos'],
    previewType: 'financeiro',
  },
  {
    id: 'negocios',
    tag: 'Empresas & Negócios',
    title: 'Gestão de Negócios',
    subtitle: 'Gira receitas, despesas operacionais e margem de lucro',
    description: 'Acompanhe a saúde financeira das suas micro ou médias empresas. Registe vendas, despesas de pessoal e faturação com relatórios de rentabilidade.',
    icon: Briefcase,
    accentColor: 'blue',
    bgGradient: 'from-blue-950/60 via-gray-900/60 to-gray-950/60',
    stats: [
      { label: 'Faturação Mensal', value: '18.200.000 KZ', badge: '+18.5%' },
      { label: 'Margem Líquida', value: '28.4%' },
      { label: 'Clientes Ativos', value: '142' },
    ],
    features: ['Controlo de fluxo de caixa', 'Indicadores de margem', 'Exportação de relatórios PDF'],
    previewType: 'negocios',
  },
  {
    id: 'patrimonio',
    tag: 'Investimentos & Ativos',
    title: 'Património Consolidação',
    subtitle: 'Acompanhe imóveis, veículos, contas e investimentos',
    description: 'Tenha uma visão holística do seu valor líquido real. Registe a aquisição, a valorização e a liquidez de todos os seus bens e investimentos.',
    icon: Building2,
    accentColor: 'amber',
    bgGradient: 'from-amber-950/60 via-gray-900/60 to-gray-950/60',
    stats: [
      { label: 'Valor Líquido', value: '45.800.000 KZ', badge: 'Crescimento +8.2%' },
      { label: 'Ativos Físicos', value: '4 imóveis / veículos' },
      { label: 'Rendimento Passivo', value: '420.000 KZ/mês' },
    ],
    features: ['Cálculo de variação patrimonial', 'Histórico de valorização', 'Taxa de liquidez'],
    previewType: 'patrimonio',
  },
  {
    id: 'marketplace',
    tag: 'Ecossistema & Trocas',
    title: 'Marketplace & Trade',
    subtitle: 'Compre, venda e encontre oportunidades no ecossistema',
    description: 'Lojas virtuais integradas, oportunidades de negócios e sinalização de trocas e ofertas exclusivas para os utilizadores da plataforma IK Finance.',
    icon: ShoppingBag,
    accentColor: 'purple',
    bgGradient: 'from-purple-950/60 via-gray-900/60 to-gray-950/60',
    stats: [
      { label: 'Anúncios Ativos', value: '350+' },
      { label: 'Negócios Fechados', value: '1.200' },
      { label: 'Classificação', value: '4.9 ★★★★★' },
    ],
    features: ['Lojas personalizadas', 'Catálogo de produtos', 'Comunicação direta via Chat'],
    previewType: 'marketplace',
  },
  {
    id: 'ai',
    tag: 'Inteligência Artificial',
    title: 'IK AI Financeira',
    subtitle: 'Assistente virtual para análises e conselhos personalizados',
    description: 'Coloque dúvidas financeiras, peça planos de redução de custos, simule amortização de dívidas e obtenha orientações em tempo real com inteligência artificial.',
    icon: Bot,
    accentColor: 'indigo',
    bgGradient: 'from-indigo-950/60 via-gray-900/60 to-gray-950/60',
    stats: [
      { label: 'Análises Geradas', value: 'Diárias' },
      { label: 'Modelo AI', value: 'Gemini Next-Gen' },
      { label: 'Precisão', value: 'Alta' },
    ],
    features: ['Dicas de poupança', 'Análise de orçamentos', 'Resumos executivos em segundos'],
    previewType: 'ai',
  },
  {
    id: 'comunidade',
    tag: 'Comunidade & Fórum',
    title: 'Feed Colaborativo',
    subtitle: 'Partilhe conhecimentos, estratégias e tire dúvidas com a rede',
    description: 'Participe em grupos temáticos sobre finanças pessoais, empreendedorismo em Angola e mercado imobiliário. Construa a sua rede de contactos.',
    icon: Users,
    accentColor: 'rose',
    bgGradient: 'from-rose-950/60 via-gray-900/60 to-gray-950/60',
    stats: [
      { label: 'Membros Ativos', value: '5.400+' },
      { label: 'Publicações', value: '120/dia' },
      { label: 'Grupos Temáticos', value: '15' },
    ],
    features: ['Debates em tempo real', 'Partilha de ficheiros', 'Networking direcionado'],
    previewType: 'comunidade',
  }
];

export default function AutoPresentationSlides({ onExplore }: { onExplore?: (slideId: string) => void }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % SLIDES.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [isPlaying]);

  const currentSlide = SLIDES[currentIndex];
  const IconComponent = currentSlide.icon;

  const nextSlide = () => setCurrentIndex((prev) => (prev + 1) % SLIDES.length);
  const prevSlide = () => setCurrentIndex((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);

  return (
    <div className="relative w-full overflow-hidden rounded-3xl border border-gray-800/80 shadow-2xl transition-all duration-700 my-6">
      {/* Dynamic Background with 60% Transparency Overlay */}
      <div className={`absolute inset-0 bg-gradient-to-br ${currentSlide.bgGradient} transition-all duration-1000 z-0`} />
      
      {/* 60% Transparency Dark Glass Overlay (Conforme pedido pelo utilizador) */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-md z-0" />

      {/* Decorative Grid Patterns */}
      <div className="absolute inset-0 bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:24px_24px] opacity-20 pointer-events-none z-0" />

      {/* Main Slide Content */}
      <div className="relative z-10 p-6 md:p-10 text-left">
        {/* Header Tag & Controls */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gray-900/80 border border-gray-700/80 backdrop-blur text-xs font-semibold text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <IconComponent size={14} className="text-emerald-400" />
            <span>{currentSlide.tag}</span>
            <span className="text-gray-500 font-normal">| {currentIndex + 1} de {SLIDES.length}</span>
          </div>

          {/* Controls bar */}
          <div className="flex items-center gap-2 bg-gray-900/80 border border-gray-800 rounded-xl p-1 backdrop-blur-md">
            <button
              onClick={prevSlide}
              className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
              title="Slide anterior"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-1.5 rounded-lg text-emerald-400 hover:bg-gray-800 transition-colors"
              title={isPlaying ? 'Pausar apresentação' : 'Reproduzir apresentação'}
            >
              {isPlaying ? <Pause size={16} /> : <Play size={16} />}
            </button>
            <button
              onClick={nextSlide}
              className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
              title="Próximo slide"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>

        {/* Slide Body Grid */}
        <div className="grid lg:grid-cols-12 gap-8 items-center">
          {/* Text & Specs */}
          <div className="lg:col-span-7 space-y-4">
            <div className="space-y-2">
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight flex items-center gap-3">
                {currentSlide.title}
              </h2>
              <p className="text-sm sm:text-base text-emerald-400/90 font-medium">
                {currentSlide.subtitle}
              </p>
            </div>

            <p className="text-gray-300 text-xs sm:text-sm leading-relaxed max-w-2xl">
              {currentSlide.description}
            </p>

            {/* Feature Bullets */}
            <div className="grid sm:grid-cols-3 gap-2 pt-2">
              {currentSlide.features.map((feat) => (
                <div key={feat} className="flex items-center gap-2 bg-gray-900/60 border border-gray-800/70 rounded-xl px-3 py-2 text-xs text-gray-200">
                  <ShieldCheck size={14} className="text-emerald-400 shrink-0" />
                  <span className="truncate">{feat}</span>
                </div>
              ))}
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-3 gap-3 pt-3 border-t border-gray-800/80">
              {currentSlide.stats.map((st) => (
                <div key={st.label} className="bg-gray-900/50 border border-gray-800/60 rounded-xl p-3">
                  <p className="text-[11px] text-gray-400 truncate">{st.label}</p>
                  <p className="text-sm sm:text-base font-bold text-white mt-0.5 truncate">{st.value}</p>
                  {st.badge && (
                    <p className="text-[10px] text-emerald-400 font-medium truncate mt-0.5">{st.badge}</p>
                  )}
                </div>
              ))}
            </div>

            {onExplore && (
              <div className="pt-2">
                <button
                  onClick={() => onExplore(currentSlide.id)}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold text-xs sm:text-sm shadow-lg shadow-emerald-950/50 transition-all"
                >
                  <span>Explorar {currentSlide.title}</span>
                  <ArrowUpRight size={16} />
                </button>
              </div>
            )}
          </div>

          {/* Interactive Live Mock Preview Card inside Slide */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl border border-gray-800 bg-gray-950/80 p-5 shadow-2xl backdrop-blur-xl space-y-4">
              <div className="flex items-center justify-between border-b border-gray-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
                    <IconComponent size={18} />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-white uppercase tracking-wider">{currentSlide.tag}</p>
                    <p className="text-[11px] text-gray-400">IK Finance Suite</p>
                  </div>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800/50 font-mono">
                  AO-LIVE
                </span>
              </div>

              {/* Dynamic Preview Graphic according to Slide */}
              {currentSlide.previewType === 'cofres' && (
                <div className="space-y-3">
                  <div className="flex justify-between text-xs text-gray-300 font-medium">
                    <span>Fundo de Emergência</span>
                    <span className="text-emerald-400 font-bold">1.200.000 / 1.500.000 KZ</span>
                  </div>
                  <div className="w-full bg-gray-800 h-3 rounded-full overflow-hidden p-0.5 border border-gray-700">
                    <div className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full w-[80%] transition-all duration-1000" />
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div className="bg-gray-900/80 p-2 rounded-lg border border-gray-800 text-gray-300">
                      <p className="text-gray-500">Estimativa Meta</p>
                      <p className="font-semibold text-white">12 Dias restantes</p>
                    </div>
                    <div className="bg-gray-900/80 p-2 rounded-lg border border-gray-800 text-gray-300">
                      <p className="text-gray-500">Cotação Média</p>
                      <p className="font-semibold text-emerald-400">920.00 AOA/USD</p>
                    </div>
                  </div>
                </div>
              )}

              {currentSlide.previewType === 'financeiro' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-400">Fluxo de Caixa Semanal</span>
                    <span className="text-xs text-emerald-400 font-semibold">+24% vs mês anterior</span>
                  </div>
                  <div className="flex items-end gap-2 h-20 pt-2">
                    {[40, 65, 35, 80, 55, 90, 75].map((h, i) => (
                      <div key={i} className="flex-1 bg-gray-900 rounded-t-md relative overflow-hidden h-full flex items-end">
                        <div
                          className="w-full bg-emerald-500/80 rounded-t-md transition-all duration-700"
                          style={{ height: `${h}%` }}
                        />
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-between text-[10px] text-gray-500">
                    <span>Seg</span><span>Ter</span><span>Qua</span><span>Qui</span><span>Sex</span><span>Sáb</span><span>Dom</span>
                  </div>
                </div>
              )}

              {currentSlide.previewType === 'negocios' && (
                <div className="space-y-2.5">
                  <div className="flex justify-between text-xs text-gray-300">
                    <span>Faturação de Vendas</span>
                    <span className="text-emerald-400 font-bold">18.2M AOA</span>
                  </div>
                  <div className="space-y-1.5">
                    <div className="bg-gray-900/90 p-2 rounded-lg border border-gray-800 flex justify-between text-xs">
                      <span className="text-gray-300">Serviços Consultoria</span>
                      <span className="text-white font-semibold">10.500.000 KZ</span>
                    </div>
                    <div className="bg-gray-900/90 p-2 rounded-lg border border-gray-800 flex justify-between text-xs">
                      <span className="text-gray-300">Vendas Loja Física</span>
                      <span className="text-white font-semibold">7.700.000 KZ</span>
                    </div>
                  </div>
                </div>
              )}

              {currentSlide.previewType === 'patrimonio' && (
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-400">Distribuição de Ativos</span>
                    <span className="text-amber-400 font-bold">45.8M AOA</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center text-[11px]">
                    <div className="bg-amber-950/30 border border-amber-900/40 p-2 rounded-xl">
                      <p className="text-amber-300 font-bold">60%</p>
                      <p className="text-gray-400 text-[10px]">Imóveis</p>
                    </div>
                    <div className="bg-emerald-950/30 border border-emerald-900/40 p-2 rounded-xl">
                      <p className="text-emerald-300 font-bold">25%</p>
                      <p className="text-gray-400 text-[10px]">Líquido</p>
                    </div>
                    <div className="bg-blue-950/30 border border-blue-900/40 p-2 rounded-xl">
                      <p className="text-blue-300 font-bold">15%</p>
                      <p className="text-gray-400 text-[10px]">Veículos</p>
                    </div>
                  </div>
                </div>
              )}

              {currentSlide.previewType === 'marketplace' && (
                <div className="space-y-2">
                  <div className="bg-purple-950/30 border border-purple-900/40 p-2.5 rounded-xl flex items-center justify-between">
                    <div>
                      <p className="text-xs font-semibold text-white">Loja Oficial Tech & Tools</p>
                      <p className="text-[10px] text-purple-300">12 Produtos em Destaque</p>
                    </div>
                    <span className="px-2 py-1 rounded-lg bg-purple-900 text-purple-200 text-[10px]">Ver Loja</span>
                  </div>
                  <div className="bg-gray-900/80 p-2 rounded-lg border border-gray-800 text-xs text-gray-300 flex items-center justify-between">
                    <span>Equipamentos de Escritório</span>
                    <span className="text-emerald-400 font-bold">350.000 KZ</span>
                  </div>
                </div>
              )}

              {currentSlide.previewType === 'ai' && (
                <div className="space-y-2">
                  <div className="bg-indigo-950/40 border border-indigo-900/50 p-2.5 rounded-xl text-xs space-y-1">
                    <div className="flex items-center gap-1.5 text-indigo-300 font-semibold">
                      <Sparkles size={13} />
                      <span>Sugestão da IA</span>
                    </div>
                    <p className="text-gray-300 text-[11px] leading-relaxed">
                      "Pode poupar 150.000 KZ este mês reduzindo despesas com refeições fora. Deseja criar um Cofre para guardar o montante?"
                    </p>
                  </div>
                </div>
              )}

              {currentSlide.previewType === 'comunidade' && (
                <div className="space-y-2">
                  <div className="bg-gray-900/90 border border-gray-800 p-2.5 rounded-xl text-xs space-y-1">
                    <p className="text-white font-semibold">Comunidade Finanças Angola</p>
                    <p className="text-gray-400 text-[11px]">
                      "Quais as melhores estratégias para proteger capital contra variação cambial?"
                    </p>
                    <div className="flex items-center gap-3 text-[10px] text-emerald-400 pt-1">
                      <span>💬 28 respostas</span>
                      <span>👍 45 gostos</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bottom Pagination Indicators Bar */}
        <div className="flex items-center justify-between pt-8 mt-6 border-t border-gray-800/80">
          <div className="flex items-center gap-2">
            {SLIDES.map((slide, idx) => (
              <button
                key={slide.id}
                onClick={() => setCurrentIndex(idx)}
                className={`h-2 rounded-full transition-all duration-500 ${
                  idx === currentIndex
                    ? 'w-8 bg-emerald-400 shadow-md shadow-emerald-500/50'
                    : 'w-2 bg-gray-700 hover:bg-gray-600'
                }`}
                title={`Ir para ${slide.title}`}
              />
            ))}
          </div>

          <div className="text-xs text-gray-400 font-medium">
            <span className="text-white font-semibold">{currentIndex + 1}</span> / {SLIDES.length}
          </div>
        </div>
      </div>
    </div>
  );
}
