import { useMemo } from 'react';
import { ShieldCheck, AlertCircle, TrendingUp, Sparkles, Target, ArrowRight, Wallet, Vault, Building2 } from 'lucide-react';
import { useCurrency } from '../context/CurrencyContext';
import type { Cofre, Transacao, Negocio, PatrimonioItem } from '../lib/supabase';

type Props = {
  cofres: Cofre[];
  transacoes: Transacao[];
  negocios: Negocio[];
  patrimonio: PatrimonioItem[];
  onNavigate: (page: string) => void;
};

export default function IKHealthScore({ cofres, transacoes, negocios, patrimonio, onNavigate }: Props) {
  const { format } = useCurrency();

  const healthData = useMemo(() => {
    // 1. Reserves Check (Cofres)
    const totalCofres = cofres.reduce((s, c) => s + (c.saldo || 0), 0);
    const txSaidas = transacoes.filter(t => t.tipo === 'saida').reduce((s, t) => s + (t.valor || 0), 0);
    const monthlyExpenses = txSaidas > 0 ? txSaidas : 100000; // default baseline if 0

    const monthsOfReserve = totalCofres / (monthlyExpenses || 1);
    const reserveScore = Math.min(30, Math.round(monthsOfReserve * 10)); // max 30 points

    // 2. Savings Rate (Entradas vs Saidas)
    const txEntradas = transacoes.filter(t => t.tipo === 'entrada').reduce((s, t) => s + (t.valor || 0), 0);
    const netIncome = txEntradas - txSaidas;
    let savingsScore = 0;
    if (txEntradas > 0) {
      const ratio = netIncome / txEntradas;
      if (ratio > 0.3) savingsScore = 25;
      else if (ratio > 0.15) savingsScore = 20;
      else if (ratio > 0) savingsScore = 15;
      else savingsScore = 5;
    } else {
      savingsScore = 10;
    }

    // 3. Diversification & Business (Patrimonio & Negocios)
    const totalPatrimonio = patrimonio.reduce((s, p) => s + (p.valor_atual || 0), 0);
    const negocioLucro = negocios.reduce((s, n) => s + ((n.receita_mensal || 0) - (n.despesa_mensal || 0)), 0);

    let assetsScore = 0;
    if (totalPatrimonio > 1000000) assetsScore += 15;
    else if (totalPatrimonio > 0) assetsScore += 10;

    if (negocioLucro > 0) assetsScore += 15;
    else if (negocios.length > 0) assetsScore += 8;

    // 4. Goals Activity (Active Cofres)
    const goalsScore = cofres.length > 0 ? 15 : 5;

    const totalScore = Math.min(100, Math.max(15, reserveScore + savingsScore + assetsScore + goalsScore));

    let statusLabel = 'Aconselhável Atenção';
    let statusColor = 'text-amber-400 border-amber-500/30 bg-amber-950/20';
    if (totalScore >= 80) {
      statusLabel = 'Excelente Saúde Financeira';
      statusColor = 'text-emerald-400 border-emerald-500/30 bg-emerald-950/20';
    } else if (totalScore >= 60) {
      statusLabel = 'Boa Estabilidade';
      statusColor = 'text-teal-400 border-teal-500/30 bg-teal-950/20';
    } else if (totalScore >= 40) {
      statusLabel = 'Em Construção';
      statusColor = 'text-blue-400 border-blue-500/30 bg-blue-950/20';
    }

    // Recommendations
    const tips = [];
    if (totalCofres === 0) {
      tips.push({ text: 'Crie um Cofre de Emergência para garantir reservas de liquidez.', action: () => onNavigate('cofres'), btnLabel: 'Criar Cofre' });
    } else if (monthsOfReserve < 3) {
      tips.push({ text: 'Aumente as suas reservas nos Cofres para cobrir pelo menos 3 meses de despesas.', action: () => onNavigate('cofres'), btnLabel: 'Ver Cofres' });
    }

    if (patrimonio.length === 0) {
      tips.push({ text: 'Registe os seus ativos em Património para calcular o seu valor líquido real.', action: () => onNavigate('patrimonio'), btnLabel: 'Ativos' });
    }

    if (negocios.length === 0) {
      tips.push({ text: 'Acompanhe as suas empresas ou projetos na secção de Negócios.', action: () => onNavigate('negocios'), btnLabel: 'Negócios' });
    }

    if (tips.length === 0) {
      tips.push({ text: 'Mantenha a disciplina de poupança e reveja as cotações nos seus Cofres mensalmente.', action: () => onNavigate('cofres'), btnLabel: 'Acompanhar' });
    }

    return { totalScore, statusLabel, statusColor, tips, totalCofres, totalPatrimonio, monthsOfReserve: monthsOfReserve.toFixed(1) };
  }, [cofres, transacoes, negocios, patrimonio, onNavigate]);

  return (
    <div className="rounded-2xl border border-gray-800 bg-gray-900/60 p-5 shadow-xl relative overflow-hidden backdrop-blur-sm">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-gray-800 pb-4 mb-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <ShieldCheck size={20} />
          </div>
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              Índice de Saúde Financeira
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800/50 font-mono">
                IK SCORE
              </span>
            </h3>
            <p className="text-xs text-gray-400">Análise inteligente baseada nos seus dados consolidados</p>
          </div>
        </div>

        <div className={`px-3 py-1.5 rounded-xl border text-xs font-semibold ${healthData.statusColor} flex items-center gap-2`}>
          <Sparkles size={14} />
          <span>{healthData.statusLabel}</span>
        </div>
      </div>

      <div className="grid md:grid-cols-12 gap-6 items-center">
        {/* Score Ring Graphic */}
        <div className="md:col-span-4 flex flex-col items-center justify-center p-4 bg-gray-950/60 rounded-xl border border-gray-800">
          <div className="relative w-28 h-28 flex items-center justify-center">
            {/* SVG Progress Circle */}
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
              <path
                className="text-gray-800"
                strokeWidth="3.5"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                className="text-emerald-400 transition-all duration-1000 ease-out"
                strokeDasharray={`${healthData.totalScore}, 100`}
                strokeWidth="3.5"
                strokeLinecap="round"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center text-center">
              <span className="text-2xl font-black text-white">{healthData.totalScore}</span>
              <span className="text-[10px] text-gray-400 font-medium uppercase">/ 100 pts</span>
            </div>
          </div>
          <p className="text-[11px] text-gray-400 mt-2 text-center">
            {healthData.monthsOfReserve} meses de reserva estimada
          </p>
        </div>

        {/* Actionable Tips */}
        <div className="md:col-span-8 space-y-3">
          <p className="text-xs font-semibold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
            <Target size={14} className="text-emerald-400" />
            Recomendações Prioritárias
          </p>

          <div className="space-y-2">
            {healthData.tips.map((tip, idx) => (
              <div key={idx} className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-gray-950/80 p-3 rounded-xl border border-gray-800/80 text-xs text-gray-300">
                <div className="flex items-start gap-2">
                  <AlertCircle size={15} className="text-emerald-400 shrink-0 mt-0.5" />
                  <span>{tip.text}</span>
                </div>
                <button
                  onClick={tip.action}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600/80 hover:bg-emerald-500 text-white font-medium text-[11px] shrink-0 transition-colors"
                >
                  <span>{tip.btnLabel}</span>
                  <ArrowRight size={12} />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
