import { useState } from 'react';
import { X, RefreshCw, Calculator, TrendingUp, Vault, Presentation, Sparkles, ArrowRight, Layers, DollarSign } from 'lucide-react';
import { useCurrency, CURRENCIES } from '../context/CurrencyContext';
import AutoPresentationSlides from './AutoPresentationSlides';

type Props = {
  isOpen: boolean;
  onClose: () => void;
  onNavigate?: (page: string) => void;
  initialTab?: 'converter' | 'goal_sim' | 'interest_sim' | 'presentation';
};

export default function QuickFinancialToolsModal({ isOpen, onClose, onNavigate, initialTab = 'converter' }: Props) {
  const [activeTab, setActiveTab] = useState<'converter' | 'goal_sim' | 'interest_sim' | 'presentation'>(initialTab);
  const { rates, format } = useCurrency();

  // Currency Converter State
  const [amountInput, setAmountInput] = useState<number>(100000); // 100,000 AOA
  const [fromCode, setFromCode] = useState<string>('AOA');
  const [toCode, setToCode] = useState<string>('USD');

  // Goal Simulator State
  const [goalAmount, setGoalAmount] = useState<number>(1500000); // 1.5M AOA
  const [monthlyContribution, setMonthlyContribution] = useState<number>(100000); // 100k AOA/mês
  const [currentSaved, setCurrentSaved] = useState<number>(200000); // 200k AOA
  const [annualInflation, setAnnualInflation] = useState<number>(12); // 12% ao ano

  // Compound Interest State
  const [initialInvestment, setInitialInvestment] = useState<number>(500000);
  const [monthlyInvest, setMonthlyInvest] = useState<number>(50000);
  const [annualInterest, setAnnualInterest] = useState<number>(15); // 15% ao ano
  const [years, setYears] = useState<number>(5);

  if (!isOpen) return null;

  // Conversão de moeda cálculo
  const getConvertedAmount = () => {
    if (!rates) return amountInput;
    // Base is AOA in open.er-api
    let inAOA = amountInput;
    if (fromCode !== 'AOA' && rates[fromCode]) {
      inAOA = amountInput / rates[fromCode];
    }
    if (toCode === 'AOA') return inAOA;
    if (rates[toCode]) return inAOA * rates[toCode];
    return inAOA;
  };

  // Cálculo da Meta em meses
  const remainingGoal = Math.max(0, goalAmount - currentSaved);
  const monthsToGoal = monthlyContribution > 0 ? Math.ceil(remainingGoal / monthlyContribution) : 0;
  // Inflação ajustada no valor final estimado
  const inflatedGoalAmount = goalAmount * Math.pow(1 + annualInflation / 100, monthsToGoal / 12);

  // Cálculo de Juros Compostos
  const calculateCompoundInterest = () => {
    const totalMonths = years * 12;
    const monthlyRate = annualInterest / 100 / 12;
    let balance = initialInvestment;
    let totalInvested = initialInvestment;

    for (let i = 0; i < totalMonths; i++) {
      balance = (balance + monthlyInvest) * (1 + monthlyRate);
      totalInvested += monthlyInvest;
    }

    const totalInterest = Math.max(0, balance - totalInvested);
    return { balance, totalInvested, totalInterest };
  };

  const compoundResult = calculateCompoundInterest();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-gray-900 border border-gray-800 rounded-3xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-gray-800 bg-gray-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <Calculator size={20} />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Ferramentas & Simuladores IK
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800">
                  Ao Vivo
                </span>
              </h2>
              <p className="text-xs text-gray-400">Conversor, projeções de metas, inflação e apresentação</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex flex-wrap items-center gap-2 px-5 pt-4 bg-gray-950/40 border-b border-gray-800 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('converter')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl border-t border-x transition-colors ${
              activeTab === 'converter'
                ? 'bg-gray-900 border-gray-800 text-emerald-400 font-bold'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <RefreshCw size={14} />
            <span>Conversor de Moedas</span>
          </button>

          <button
            onClick={() => setActiveTab('goal_sim')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl border-t border-x transition-colors ${
              activeTab === 'goal_sim'
                ? 'bg-gray-900 border-gray-800 text-emerald-400 font-bold'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <Vault size={14} />
            <span>Simulador de Meta & Inflação</span>
          </button>

          <button
            onClick={() => setActiveTab('interest_sim')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl border-t border-x transition-colors ${
              activeTab === 'interest_sim'
                ? 'bg-gray-900 border-gray-800 text-emerald-400 font-bold'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <TrendingUp size={14} />
            <span>Juros Compostos</span>
          </button>

          <button
            onClick={() => setActiveTab('presentation')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl border-t border-x transition-colors ${
              activeTab === 'presentation'
                ? 'bg-gray-900 border-gray-800 text-emerald-400 font-bold'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <Presentation size={14} />
            <span>Modo Apresentação (Slides)</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-6">
          {activeTab === 'converter' && (
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                {/* De */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-gray-400">Montante de Origem</label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={amountInput}
                      onChange={(e) => setAmountInput(Math.max(0, Number(e.target.value)))}
                      className="flex-1 bg-gray-950 border border-gray-800 rounded-xl px-4 py-3 text-white text-base font-semibold focus:outline-none focus:border-emerald-500"
                    />
                    <select
                      value={fromCode}
                      onChange={(e) => setFromCode(e.target.value)}
                      className="bg-gray-950 border border-gray-800 rounded-xl px-3 py-3 text-white text-sm font-bold focus:outline-none focus:border-emerald-500"
                    >
                      {CURRENCIES.map((c) => (
                        <option key={c.code} value={c.code}>
                          {c.flag} {c.code}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Para */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-gray-400">Moeda de Destino</label>
                  <div className="flex gap-2">
                    <div className="flex-1 bg-gray-950/80 border border-emerald-900/50 rounded-xl px-4 py-3 text-emerald-400 text-base font-bold flex items-center">
                      {getConvertedAmount().toLocaleString('pt-AO', { maximumFractionDigits: 2 })}
                    </div>
                    <select
                      value={toCode}
                      onChange={(e) => setToCode(e.target.value)}
                      className="bg-gray-950 border border-gray-800 rounded-xl px-3 py-3 text-white text-sm font-bold focus:outline-none focus:border-emerald-500"
                    >
                      {CURRENCIES.map((c) => (
                        <option key={c.code} value={c.code}>
                          {c.flag} {c.code}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Quick Rates Bar */}
              <div className="bg-gray-950/60 border border-gray-800 rounded-2xl p-4">
                <p className="text-xs font-semibold text-gray-400 mb-3 uppercase tracking-wider">
                  Taxas de Câmbio de Referência (Base Kwanza)
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {['USD', 'EUR', 'BRL', 'ZAR'].map((code) => {
                    const rate = rates ? rates[code] : null;
                    const inAOA = rate ? (1 / rate) : 0;
                    return (
                      <div key={code} className="bg-gray-900/80 border border-gray-800 p-3 rounded-xl text-center">
                        <p className="text-[11px] text-gray-500 font-semibold">1 {code}</p>
                        <p className="text-sm font-bold text-white mt-1">
                          {inAOA ? `${inAOA.toFixed(2)} KZ` : 'A carregar...'}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'goal_sim' && (
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-gray-400">Valor da Meta (KZ)</label>
                    <input
                      type="number"
                      value={goalAmount}
                      onChange={(e) => setGoalAmount(Number(e.target.value))}
                      className="w-full mt-1 bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-gray-400">Ja Salvo / Inicial (KZ)</label>
                    <input
                      type="number"
                      value={currentSaved}
                      onChange={(e) => setCurrentSaved(Number(e.target.value))}
                      className="w-full mt-1 bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-gray-400">Depósito Mensal Planeado (KZ)</label>
                    <input
                      type="number"
                      value={monthlyContribution}
                      onChange={(e) => setMonthlyContribution(Number(e.target.value))}
                      className="w-full mt-1 bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-gray-400">Estimativa de Inflação Anual (%)</label>
                    <input
                      type="number"
                      value={annualInflation}
                      onChange={(e) => setAnnualInflation(Number(e.target.value))}
                      className="w-full mt-1 bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-white font-bold"
                    />
                  </div>
                </div>

                {/* Calculation Output Card */}
                <div className="bg-gray-950/80 border border-gray-800 rounded-2xl p-5 flex flex-col justify-between space-y-4">
                  <div>
                    <p className="text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-2">
                      Resultado da Projeção
                    </p>
                    <h3 className="text-2xl font-black text-white">
                      {monthsToGoal > 0 ? `${monthsToGoal} Meses` : 'Meta Concluída!'}
                    </h3>
                    <p className="text-xs text-gray-400 mt-1">
                      Aproximadamente {(monthsToGoal / 12).toFixed(1)} anos com o ritmo atual.
                    </p>
                  </div>

                  <div className="space-y-2 border-t border-gray-800 pt-3 text-xs">
                    <div className="flex justify-between text-gray-300">
                      <span>Falta Acumular:</span>
                      <span className="font-bold text-white">{format(remainingGoal)}</span>
                    </div>
                    <div className="flex justify-between text-gray-300">
                      <span>Valor Ajustado à Inflação:</span>
                      <span className="font-bold text-amber-400">{format(inflatedGoalAmount)}</span>
                    </div>
                  </div>

                  {onNavigate && (
                    <button
                      onClick={() => {
                        onClose();
                        onNavigate('cofres');
                      }}
                      className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors"
                    >
                      <span>Criar este Cofre Agora</span>
                      <ArrowRight size={14} />
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'interest_sim' && (
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-gray-400">Aporte Inicial (KZ)</label>
                    <input
                      type="number"
                      value={initialInvestment}
                      onChange={(e) => setInitialInvestment(Number(e.target.value))}
                      className="w-full mt-1 bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-gray-400">Aporte Mensal (KZ)</label>
                    <input
                      type="number"
                      value={monthlyInvest}
                      onChange={(e) => setMonthlyInvest(Number(e.target.value))}
                      className="w-full mt-1 bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-gray-400">Taxa de Juros Anual (%)</label>
                    <input
                      type="number"
                      value={annualInterest}
                      onChange={(e) => setAnnualInterest(Number(e.target.value))}
                      className="w-full mt-1 bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-gray-400">Período (Anos)</label>
                    <input
                      type="number"
                      value={years}
                      onChange={(e) => setYears(Math.max(1, Number(e.target.value)))}
                      className="w-full mt-1 bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-white font-bold"
                    />
                  </div>
                </div>

                <div className="bg-gray-950/80 border border-gray-800 rounded-2xl p-5 flex flex-col justify-between space-y-4">
                  <div>
                    <p className="text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-2">
                      Montante Final Estimado
                    </p>
                    <h3 className="text-2xl sm:text-3xl font-black text-white">
                      {format(compoundResult.balance)}
                    </h3>
                  </div>

                  <div className="space-y-2 border-t border-gray-800 pt-3 text-xs">
                    <div className="flex justify-between text-gray-300">
                      <span>Total Investido do Seu Bolso:</span>
                      <span className="font-bold text-white">{format(compoundResult.totalInvested)}</span>
                    </div>
                    <div className="flex justify-between text-emerald-400 font-bold">
                      <span>Lucro Gerado em Juros:</span>
                      <span>+ {format(compoundResult.totalInterest)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'presentation' && (
            <div>
              <AutoPresentationSlides
                onExplore={(slideId) => {
                  onClose();
                  if (onNavigate) onNavigate(slideId);
                }}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
