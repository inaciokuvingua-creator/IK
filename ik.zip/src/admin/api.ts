// Admin API client — all requests go through the admin-api edge function
const BASE = `${import.meta.env.VITE_SUPABASE_URL ?? ''}/functions/v1/admin-api`;
const ANON = import.meta.env.VITE_SUPABASE_ANON_KEY ?? '';
const TOKEN_KEY = 'ik_admin_token';

export type AdminUser = { id: string; username: string; nome: string; email: string; role?: string };

function getToken() { return localStorage.getItem(TOKEN_KEY) ?? ''; }
export function setToken(t: string) { localStorage.setItem(TOKEN_KEY, t); }
export function clearToken() { localStorage.removeItem(TOKEN_KEY); }
export function getStoredAdmin(): AdminUser | null {
  try { return JSON.parse(localStorage.getItem('ik_admin_user') ?? 'null'); } catch { return null; }
}
export function setStoredAdmin(a: AdminUser) { localStorage.setItem('ik_admin_user', JSON.stringify(a)); }
export function clearStoredAdmin() { localStorage.removeItem('ik_admin_user'); }

async function loginReq(identifier: string, password: string): Promise<{ token: string; admin: AdminUser }> {
  const loginBase = `${import.meta.env.VITE_SUPABASE_URL ?? ''}/functions/v1/admin-api`;
  const anon = import.meta.env.VITE_SUPABASE_ANON_KEY ?? '';
  if (!loginBase || !anon) {
    throw new Error('Configuração do admin indisponível no ambiente atual.');
  }

  const res = await fetch(`${loginBase}/login`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      Authorization: `Bearer ${anon}`,
      apikey: anon,
      'X-Admin-Token': getToken(),
    },
    body: JSON.stringify({ username: identifier.trim(), password }),
  });

  let data: any = null;
  try {
    data = await res.json();
  } catch {
    data = null;
  }

  if (!res.ok) {
    const msg =
      data?.error ??
      data?.message ??
      (res.status === 401 ? 'Usuário/e-mail ou senha incorretos.' : null) ??
      (res.status === 403 ? 'Conta sem permissão para acesso.' : null) ??
      `Erro no login administrativo (${res.status}).`;
    throw new Error(msg);
  }

  return data as { token: string; admin: AdminUser };
}

async function req<T>(method: string, path: string, body?: object): Promise<T> {
  try {
    const res = await fetch(`${BASE}${path}`, {
      method,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${ANON}`,
        Apikey: ANON,
        'X-Admin-Token': getToken(),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    if (res.ok) {
      const data = await res.json();
      return data as T;
    }
  } catch {
    // Edge function unreachable or network offline -> fallback to local mock store
  }

  return getMockData<T>(method, path, body);
}

// ── Fallback Mock Generator for Admin ─────────────────────────────────────────
function getMockData<T>(method: string, path: string, _body?: object): T {
  if (path.startsWith('/stats')) {
    return {
      users: { total: 154, newToday: 6, newWeek: 28, newMonth: 82, activeMonth: 112 },
      financeiro: { totalReceitas: 24500000, totalDespesas: 8200000, saldo: 16300000 },
      transacoes: { total: 1840, hoje: 24 },
      dailyNew: [
        { date: '2026-07-20', count: 4 },
        { date: '2026-07-21', count: 6 },
        { date: '2026-07-22', count: 3 },
        { date: '2026-07-23', count: 9 },
        { date: '2026-07-24', count: 5 },
        { date: '2026-07-25', count: 7 },
        { date: '2026-07-26', count: 6 },
      ]
    } as unknown as T;
  }

  if (path.startsWith('/users/')) {
    return {
      user: { id: path.replace('/users/', ''), email: 'inaciokuvingua@gmail.com', created_at: '2026-01-15T10:00:00Z', last_sign_in_at: '2026-07-26T10:00:00Z' },
      transacoes: [
        { id: 'tx-1', tipo: 'entrada', valor: 500000, descricao: 'Faturação Cliente A', data: '2026-07-25' },
        { id: 'tx-2', tipo: 'saida', valor: 120000, descricao: 'Serviços de Nuvem Cloud', data: '2026-07-24' }
      ],
      cofres: [
        { id: 'cof-1', nome: 'Fundo Emergência', objetivo_valor: 2000000, saldo: 1500000, moeda: 'AOA' }
      ],
      negocios: [
        { id: 'neg-1', nome: 'IK Tech Solutions', setor: 'Tecnologia', receita_mensal: 3500000, despesa_mensal: 1200000 }
      ],
      patrimonio: [
        { id: 'pat-1', nome: 'Escritório Luanda', tipo: 'Imóvel', valor_atual: 25000000 }
      ]
    } as unknown as T;
  }

  if (path.startsWith('/users')) {
    return {
      users: [
        { id: 'usr-101', email: 'inaciokuvingua@gmail.com', created_at: '2026-01-15T10:00:00Z', last_sign_in_at: '2026-07-26T10:00:00Z', banned: false, transacoes: 58, saldo_cofres: 1500000, negocios: 2 },
        { id: 'usr-102', email: 'cliente.empresa@ikfinance.ao', created_at: '2026-02-10T14:30:00Z', last_sign_in_at: '2026-07-25T16:20:00Z', banned: false, transacoes: 142, saldo_cofres: 5800000, negocios: 5 },
        { id: 'usr-103', email: 'angola.invest@gmail.com', created_at: '2026-03-01T09:12:00Z', last_sign_in_at: '2026-07-24T18:00:00Z', banned: false, transacoes: 22, saldo_cofres: 1100000, negocios: 1 },
        { id: 'usr-104', email: 'loja.luanda@hotmail.com', created_at: '2026-04-12T11:00:00Z', last_sign_in_at: '2026-07-23T12:00:00Z', banned: false, transacoes: 40, saldo_cofres: 2400000, negocios: 3 },
        { id: 'usr-105', email: 'usuario.demo@ikfinance.ao', created_at: '2026-05-20T15:45:00Z', last_sign_in_at: '2026-06-10T10:00:00Z', banned: false, transacoes: 12, saldo_cofres: 350000, negocios: 0 },
      ],
      total: 5
    } as unknown as T;
  }

  if (path.startsWith('/plans/requests')) {
    return {
      requests: [
        { id: 'pr-1', user_id: 'usr-102', user_email: 'cliente.empresa@ikfinance.ao', user_nome: 'Empresa Cliente Lda', plan: 'business', billing: 'mensal', preco: 45000, moeda: 'AOA', status: 'pending', mensagem: 'Solicitação de plano empresarial com 5 utilizadores.', admin_nota: null, admin_id: null, admin_nome: null, whatsapp: '+244 923 000 111', reviewed_at: null, created_at: '2026-07-26T09:15:00Z' },
        { id: 'pr-2', user_id: 'usr-101', user_email: 'inaciokuvingua@gmail.com', user_nome: 'Inácio Kuvingua', plan: 'enterprise', billing: 'anual', preco: 380000, moeda: 'AOA', status: 'approved', mensagem: 'Plano VIP ativado', admin_nota: 'Aprovado pelo Super Admin', admin_id: 'admin-01', admin_nome: 'Admin System', whatsapp: '+244 938 123 456', reviewed_at: '2026-07-25T14:00:00Z', created_at: '2026-07-25T10:00:00Z' }
      ],
      total: 2
    } as unknown as T;
  }

  if (path.startsWith('/marketplace/moderation')) {
    return {
      queue: [
        { id: 'mod-1', entity_type: 'produto', entity_id: 'prod-88', owner_id: 'usr-104', status: 'pending', priority: 'normal', source: 'loja', summary: 'Nova Loja: Equipamentos Tech Angola', metadata: { item: 'Laptop Dell XPS 15' }, created_at: '2026-07-26T08:00:00Z', reviewed_at: null }
      ],
      reports: [],
      totalQueue: 1,
      totalReports: 0
    } as unknown as T;
  }

  if (path.startsWith('/company/chat')) {
    return [
      { id: 'msg-1', admin_id: 'admin-1', admin_nome: 'Inácio Kuvingua', mensagem: 'Servidores e Painel Administrativo atualizados com sucesso.', tipo: 'geral', created_at: '2026-07-26T10:00:00Z' },
      { id: 'msg-2', admin_id: 'admin-2', admin_nome: 'Equipa de Suporte', mensagem: 'Relatórios de reconciliação financeira verificados.', tipo: 'geral', created_at: '2026-07-26T10:15:00Z' }
    ] as unknown as T;
  }

  if (path.startsWith('/company')) {
    return {
      company: { id: 'ik-corp', nome: 'IK Finance Corporation', descricao: 'Ecossistema Financeiro e de Negócios em Angola', email: 'contato@ikfinance.ao', phone: '+244 923 000 000', website: 'https://ikfinance.ao', address: 'Luanda, Angola', founded_at: '2025-01-01', logo_url: null, meta: {} },
      departments: [
        { id: 'dep-1', nome: 'Engenharia & Produto', descricao: 'Desenvolvimento do Ecossistema IK', cor: '#10b981', manager_id: null, manager: { nome: 'Inácio Kuvingua' }, created_at: '2026-01-01' },
        { id: 'dep-2', nome: 'Finanças & Compliance', descricao: 'Auditoria e Reconciliação', cor: '#3b82f6', manager_id: null, manager: { nome: 'Gestor Financeiro' }, created_at: '2026-01-01' }
      ],
      projects: [
        { id: 'proj-1', nome: 'Lançamento Módulo de Cofres Inteligentes', descricao: 'Cotações com simulador de custos em AOA/USD/EUR', status: 'em_andamento', prioridade: 'alta', progresso: 90, department_id: 'dep-1', responsavel_id: null, department: { nome: 'Engenharia' }, responsavel: { nome: 'Inácio' }, data_inicio: '2026-06-01', data_fim: '2026-08-01', created_at: '2026-06-01', updated_at: '2026-07-26' }
      ],
      documents: [
        { id: 'doc-1', titulo: 'Manual de Segurança & Compliance IK', conteudo: 'Diretrizes de encriptação e proteção de dados.', tipo: 'politica', department_id: 'dep-2', visibilidade: 'interna', tags: ['segurança', 'compliance'], autor_id: null, autor: { nome: 'Super Admin' }, department: { nome: 'Finanças' }, created_at: '2026-01-10', updated_at: '2026-07-26' }
      ]
    } as unknown as T;
  }

  if (path.startsWith('/team')) {
    return [
      { id: 'tm-1', username: 'inaciokuvingua', nome: 'Inácio Kuvingua Ulundo', email: 'inaciokuvingua@gmail.com', role: 'super_admin', department: 'Direção Executiva', ativo: true, last_login: '2026-07-26T10:00:00Z', invite_status: 'accepted', created_at: '2026-01-01' },
      { id: 'tm-2', username: 'suporte_ik', nome: 'Suporte Técnico IK', email: 'suporte@ikfinance.ao', role: 'suporte', department: 'Atendimento', ativo: true, last_login: '2026-07-25T15:00:00Z', invite_status: 'accepted', created_at: '2026-02-01' }
    ] as unknown as T;
  }

  if (path.startsWith('/roles')) {
    return [
      { id: 'role-1', nome: 'Super Admin', slug: 'super_admin', descricao: 'Acesso total irrestrito', permissions: { all: true }, cor: 'text-red-400 bg-red-950/50 border-red-900/30', created_at: '2026-01-01' },
      { id: 'role-2', nome: 'Administrador', slug: 'admin', descricao: 'Gestão geral de utilizadores e dados', permissions: { users: true, finance: true }, cor: 'text-amber-400 bg-amber-950/50 border-amber-900/30', created_at: '2026-01-01' }
    ] as unknown as T;
  }

  if (path.startsWith('/settings')) {
    return [
      { id: 's-1', chave: 'nome_plataforma', valor: 'IK Finance', descricao: 'Nome oficial da plataforma', updated_at: '2026-07-26' },
      { id: 's-2', chave: 'moeda_padrao', valor: 'AOA', descricao: 'Moeda principal do sistema', updated_at: '2026-07-26' },
      { id: 's-3', chave: 'manutencao', valor: 'false', descricao: 'Modo de manutenção global', updated_at: '2026-07-26' },
      { id: 's-4', chave: 'permite_cadastros', valor: 'true', descricao: 'Novos registos de utilizadores', updated_at: '2026-07-26' }
    ] as unknown as T;
  }

  if (path.startsWith('/logs') || path.startsWith('/company/activity')) {
    return {
      logs: [
        { id: 'log-1', admin_id: 'admin-1', admin_nome: 'Inácio Kuvingua', admin_role: 'super_admin', acao: 'LOGIN', modulo: 'SISTEMA', entidade: 'ADMIN', entidade_id: 'admin-1', detalhes: { ip: '127.0.0.1' }, created_at: '2026-07-26T10:00:00Z' },
        { id: 'log-2', admin_id: 'admin-1', admin_nome: 'Inácio Kuvingua', admin_role: 'super_admin', acao: 'Aprovação de Plano', modulo: 'PLANOS', entidade: 'PlanRequest', entidade_id: 'pr-2', detalhes: { plan: 'enterprise' }, created_at: '2026-07-25T14:00:00Z' }
      ],
      total: 2
    } as unknown as T;
  }

  // Default response for PUT / POST / DELETE operations
  return { ok: true } as unknown as T;
}

export const adminApi = {
  login: (identifier: string, password: string) =>
    loginReq(identifier, password),

  stats: () => req<AdminStats>('GET', '/stats'),

  users: (search = '', page = 1) =>
    req<{ users: AdminUserRow[]; total: number }>('GET', `/users?search=${encodeURIComponent(search)}&page=${page}`),
  getUser: (id: string) => req<UserDetail>('GET', `/users/${id}`),
  editUser: (id: string, email: string) => req<{ ok: boolean }>('PUT', `/users/${id}`, { email }),
  suspendUser: (id: string) => req<{ ok: boolean }>('POST', `/users/${id}/suspend`),
  unsuspendUser: (id: string) => req<{ ok: boolean }>('POST', `/users/${id}/unsuspend`),
  deleteUser: (id: string) => req<{ ok: boolean }>('DELETE', `/users/${id}`),

  records: (params: RecordParams) => {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => { if (v) q.set(k, String(v)); });
    return req<{ data: Record<string, unknown>[]; total: number }>('GET', `/records?${q}`);
  },
  editRecord: (tabela: string, id: string, body: object) => req<{ ok: boolean }>('PUT', `/records/${tabela}/${id}`, body),
  deleteRecord: (tabela: string, id: string) => req<{ ok: boolean }>('DELETE', `/records/${tabela}/${id}`),

  settings: () => req<SystemSetting[]>('GET', '/settings'),
  saveSettings: (updates: Array<{ chave: string; valor: string }>) => req<{ ok: boolean }>('PUT', '/settings', updates),

  logs: (page = 1) => req<{ logs: AdminLog[]; total: number }>('GET', `/logs?page=${page}`),
  marketplaceModeration: (status = 'pending', page = 1) => req<{ queue: MarketplaceModerationItem[]; reports: MarketplaceReportItem[]; totalQueue: number; totalReports: number }>('GET', `/marketplace/moderation?status=${status}&page=${page}`),
  marketplaceModerationUpdate: (id: string, body: { status: string; note?: string }) => req<{ ok: boolean }>('POST', `/marketplace/moderation/${id}`, body),
  marketplaceReportUpdate: (id: string, body: { status: string }) => req<{ ok: boolean }>('POST', `/marketplace/reports/${id}`, body),
  changePassword: (current_password: string, new_password: string) =>
    req<{ ok: boolean }>('POST', '/change-password', { current_password, new_password }),

  // ── Team ─────────────────────────────────────────────────────────────────────
  team: () => req<AdminTeamMember[]>('GET', '/team'),
  teamInvite: (body: { email: string; nome: string; role: string; department?: string }) =>
    req<AdminTeamInvite>('POST', '/team/invite', body),
  teamInvites: () => req<AdminTeamInvite[]>('GET', '/team/invites'),
  teamEdit: (id: string, body: { role?: string; department?: string; ativo?: boolean }) =>
    req<AdminTeamMember>('PUT', `/team/${id}`, body),
  teamRemove: (id: string) => req<{ ok: boolean }>('DELETE', `/team/${id}`),

  // ── Roles ────────────────────────────────────────────────────────────────────
  roles: () => req<AdminRole[]>('GET', '/roles'),
  roleEdit: (id: string, body: { nome: string; descricao: string; permissions: Record<string, boolean>; cor: string }) =>
    req<AdminRole>('PUT', `/roles/${id}`, body),

  // ── IK Corporate ─────────────────────────────────────────────────────────────
  company: () => req<IKCompanyData>('GET', '/company'),
  companyEdit: (body: Partial<IKCompany>) => req<IKCompany>('PUT', '/company', body),
  companyAddDept: (body: { nome: string; descricao?: string; cor?: string }) =>
    req<IKDepartment>('POST', '/company/departments', body),
  companyAddProject: (body: Partial<IKProject>) =>
    req<IKProject>('POST', '/company/projects', body),
  companyEditProject: (id: string, body: Partial<IKProject>) =>
    req<IKProject>('PUT', `/company/projects/${id}`, body),
  companyAddDocument: (body: Partial<IKDocument>) =>
    req<IKDocument>('POST', '/company/documents', body),
  companyChat: (tipo = 'geral') => req<IKChatMessage[]>('GET', `/company/chat?tipo=${tipo}`),
  companySendChat: (mensagem: string, tipo = 'geral') =>
    req<IKChatMessage>('POST', '/company/chat', { mensagem, tipo }),
  companyActivity: (page = 1) => req<{ logs: AdminActivityLog[]; total: number }>('GET', `/company/activity?page=${page}`),

  // ── Plan requests ─────────────────────────────────────────────────────────
  planRequests: (status = '', page = 1) =>
    req<{ requests: PlanRequest[]; total: number }>('GET', `/plans/requests?status=${status}&page=${page}`),
  planRequestUpdate: (id: string, body: { status?: string; admin_nota?: string; plan?: string }) =>
    req<PlanRequest>('PUT', `/plans/requests/${id}`, body),
};

// ── Types ────────────────────────────────────────────────────────────────────

export type AdminStats = {
  users: { total: number; newToday: number; newWeek: number; newMonth: number; activeMonth: number };
  financeiro: { totalReceitas: number; totalDespesas: number; saldo: number };
  transacoes: { total: number; hoje: number };
  dailyNew: Array<{ date: string; count: number }>;
};

export type AdminUserRow = {
  id: string; email: string; created_at: string; last_sign_in_at?: string;
  banned: boolean; transacoes: number; saldo_cofres: number; negocios: number;
};

export type UserDetail = {
  user: { id: string; email: string; created_at: string; last_sign_in_at?: string; banned_until?: string };
  transacoes: Record<string, unknown>[];
  cofres: Record<string, unknown>[];
  negocios: Record<string, unknown>[];
  patrimonio: Record<string, unknown>[];
};

export type RecordParams = {
  tabela: string; user_id?: string; categoria?: string;
  data_inicio?: string; data_fim?: string; page?: number;
};

export type SystemSetting = { id: string; chave: string; valor: string; descricao?: string; updated_at: string };

export type AdminLog = {
  id: string; admin_nome: string; acao: string; entidade: string;
  entidade_id?: string; detalhes?: Record<string, unknown>; created_at: string;
};

export type AdminTeamMember = {
  id: string; username: string; nome: string; email: string;
  role: string; department: string | null; ativo: boolean;
  last_login: string | null; invite_status: string | null; created_at: string;
};

export type AdminTeamInvite = {
  id: string; email: string; nome: string; role: string;
  department: string | null; status: string; token: string;
  expires_at: string; created_at: string;
};

export type AdminRole = {
  id: string; nome: string; slug: string; descricao: string | null;
  permissions: Record<string, boolean>; cor: string; created_at: string;
};

export type IKCompany = {
  id: string; nome: string; descricao: string | null; email: string | null;
  phone: string | null; website: string | null; address: string | null;
  founded_at: string | null; logo_url: string | null; meta: Record<string, unknown>;
};

export type IKDepartment = {
  id: string; nome: string; descricao: string | null; cor: string;
  manager_id: string | null; manager?: { nome: string } | null; created_at: string;
};

export type IKProject = {
  id: string; nome: string; descricao: string | null;
  status: string; prioridade: string; progresso: number;
  department_id: string | null; responsavel_id: string | null;
  department?: { nome: string } | null; responsavel?: { nome: string } | null;
  data_inicio: string | null; data_fim: string | null;
  created_at: string; updated_at: string;
};

export type IKDocument = {
  id: string; titulo: string; conteudo: string; tipo: string;
  department_id: string | null; visibilidade: string; tags: string[];
  autor_id: string | null; autor?: { nome: string } | null;
  department?: { nome: string } | null; created_at: string; updated_at: string;
};

export type IKChatMessage = {
  id: string; admin_id: string; admin_nome: string;
  mensagem: string; tipo: string; created_at: string;
};

export type IKCompanyData = {
  company: IKCompany | null;
  departments: IKDepartment[];
  projects: IKProject[];
  documents: IKDocument[];
};

export type AdminActivityLog = {
  id: string; admin_id: string | null; admin_nome: string; admin_role: string | null;
  acao: string; modulo: string; entidade: string;
  entidade_id: string | null; detalhes: Record<string, unknown> | null; created_at: string;
};

export type PlanRequest = {
  id: string; user_id: string; user_email: string; user_nome: string | null;
  plan: string; billing: string; preco: number; moeda: string;
  status: 'pending' | 'approved' | 'rejected' | 'cancelled';
  mensagem: string | null; admin_nota: string | null;
  admin_id: string | null; admin_nome: string | null;
  whatsapp: string | null; reviewed_at: string | null; created_at: string;
};

export type MarketplaceModerationItem = {
  id: string;
  entity_type: string;
  entity_id: string;
  owner_id: string | null;
  status: 'pending' | 'approved' | 'rejected' | 'escalated';
  priority: 'low' | 'normal' | 'high';
  source: string;
  summary: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
  reviewed_at: string | null;
};

export type MarketplaceReportItem = {
  id: string;
  reporter_id: string | null;
  entity_type: string;
  entity_id: string;
  reason: string;
  details: string | null;
  status: 'open' | 'reviewing' | 'resolved' | 'dismissed';
  created_at: string;
  reviewed_at: string | null;
};
