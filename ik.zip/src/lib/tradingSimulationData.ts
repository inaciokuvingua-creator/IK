import type { TradingAsset, AssetType } from '../types/trading';

export interface Candle {
  time: string;
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface OrderBookItem {
  price: number;
  amount: number;
  total: number;
}

export interface OrderBookData {
  asks: OrderBookItem[];
  bids: OrderBookItem[];
  spread: number;
}

export interface MarketRecentTrade {
  id: string;
  price: number;
  amount: number;
  time: string;
  side: 'buy' | 'sell';
}

export interface ExtendedAsset extends TradingAsset {
  last_price: number;
  price_change_percent_24h: number;
  high_24h: number;
  low_24h: number;
  volume_24h: number;
  category: AssetType;
  base_currency: string;
  quote_currency: string;
  min_order_size: number;
  max_leverage: number;
  precision: number;
  description: string;
}

// Catálogo completo de Ativos Globais (Cripto, Forex, Ações, Commodities, Índices)
export const MARKET_CATALOG: ExtendedAsset[] = [
  // CRIPTO
  {
    id: 'btc-usdt',
    symbol: 'BTC/USDT',
    name: 'Bitcoin',
    type: 'crypto',
    category: 'crypto',
    exchange: 'Binance / Bybit',
    is_active: true,
    last_price: 67450.00,
    price_change_percent_24h: 3.42,
    high_24h: 68120.00,
    low_24h: 65200.00,
    volume_24h: 2845012000,
    base_currency: 'BTC',
    quote_currency: 'USDT',
    min_order_size: 0.001,
    max_leverage: 125,
    precision: 2,
    description: 'Maior criptomoeda do mundo em capitalização de mercado.',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'eth-usdt',
    symbol: 'ETH/USDT',
    name: 'Ethereum',
    type: 'crypto',
    category: 'crypto',
    exchange: 'Binance / Bybit',
    is_active: true,
    last_price: 3520.50,
    price_change_percent_24h: -1.15,
    high_24h: 3610.00,
    low_24h: 3480.20,
    volume_24h: 1420800000,
    base_currency: 'ETH',
    quote_currency: 'USDT',
    min_order_size: 0.01,
    max_leverage: 100,
    precision: 2,
    description: 'Líder em contratos inteligentes e finanças descentralizadas.',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'sol-usdt',
    symbol: 'SOL/USDT',
    name: 'Solana',
    type: 'crypto',
    category: 'crypto',
    exchange: 'Binance / Bybit',
    is_active: true,
    last_price: 184.20,
    price_change_percent_24h: 7.85,
    high_24h: 189.50,
    low_24h: 170.10,
    volume_24h: 980500000,
    base_currency: 'SOL',
    quote_currency: 'USDT',
    min_order_size: 0.1,
    max_leverage: 75,
    precision: 2,
    description: 'Blockchain de altíssimo desempenho e baixas taxas.',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'bnb-usdt',
    symbol: 'BNB/USDT',
    name: 'BNB Chain',
    type: 'crypto',
    category: 'crypto',
    exchange: 'Binance',
    is_active: true,
    last_price: 588.30,
    price_change_percent_24h: 1.28,
    high_24h: 595.00,
    low_24h: 580.10,
    volume_24h: 420100000,
    base_currency: 'BNB',
    quote_currency: 'USDT',
    min_order_size: 0.05,
    max_leverage: 75,
    precision: 2,
    description: 'Moeda nativa do ecossistema Binance.',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'xrp-usdt',
    symbol: 'XRP/USDT',
    name: 'Ripple',
    type: 'crypto',
    category: 'crypto',
    exchange: 'Binance / Bybit',
    is_active: true,
    last_price: 0.6125,
    price_change_percent_24h: 4.12,
    high_24h: 0.6350,
    low_24h: 0.5890,
    volume_24h: 610000000,
    base_currency: 'XRP',
    quote_currency: 'USDT',
    min_order_size: 10,
    max_leverage: 50,
    precision: 4,
    description: 'Focada em liquidação rápida de pagamentos transfronteiriços.',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },

  // FOREX
  {
    id: 'eur-usd',
    symbol: 'EUR/USD',
    name: 'Euro / US Dollar',
    type: 'forex',
    category: 'forex',
    exchange: 'FXCM / OANDA',
    is_active: true,
    last_price: 1.0864,
    price_change_percent_24h: 0.18,
    high_24h: 1.0892,
    low_24h: 1.0840,
    volume_24h: 12500000000,
    base_currency: 'EUR',
    quote_currency: 'USD',
    min_order_size: 1000,
    max_leverage: 100,
    precision: 5,
    description: 'Par de moedas mais negociado do mercado financeiro global.',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'gbp-usd',
    symbol: 'GBP/USD',
    name: 'British Pound / US Dollar',
    type: 'forex',
    category: 'forex',
    exchange: 'FXCM / OANDA',
    is_active: true,
    last_price: 1.2940,
    price_change_percent_24h: -0.32,
    high_24h: 1.2995,
    low_24h: 1.2910,
    volume_24h: 8400000000,
    base_currency: 'GBP',
    quote_currency: 'USD',
    min_order_size: 1000,
    max_leverage: 100,
    precision: 5,
    description: 'Conhecido como Cable no mercado de câmbio.',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'usd-jpy',
    symbol: 'USD/JPY',
    name: 'US Dollar / Japanese Yen',
    type: 'forex',
    category: 'forex',
    exchange: 'FXCM / OANDA',
    is_active: true,
    last_price: 154.85,
    price_change_percent_24h: 0.65,
    high_24h: 155.40,
    low_24h: 153.90,
    volume_24h: 9100000000,
    base_currency: 'USD',
    quote_currency: 'JPY',
    min_order_size: 1000,
    max_leverage: 100,
    precision: 3,
    description: 'Par principal de refúgio cambial asiático.',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },

  // COMMODITIES & INDICES
  {
    id: 'xau-usd',
    symbol: 'XAU/USD',
    name: 'Gold Spot',
    type: 'commodities',
    category: 'commodities',
    exchange: 'COMEX / Spot',
    is_active: true,
    last_price: 2415.80,
    price_change_percent_24h: 1.12,
    high_24h: 2432.00,
    low_24h: 2390.50,
    volume_24h: 4200000000,
    base_currency: 'XAU',
    quote_currency: 'USD',
    min_order_size: 0.1,
    max_leverage: 100,
    precision: 2,
    description: 'Ativo de reserva física de valor e proteção contra inflação.',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'wti-usd',
    symbol: 'WTI/USD',
    name: 'Crude Oil WTI',
    type: 'commodities',
    category: 'commodities',
    exchange: 'NYMEX',
    is_active: true,
    last_price: 78.45,
    price_change_percent_24h: -1.85,
    high_24h: 80.20,
    low_24h: 77.90,
    volume_24h: 2100000000,
    base_currency: 'WTI',
    quote_currency: 'USD',
    min_order_size: 1,
    max_leverage: 50,
    precision: 2,
    description: 'Petróleo bruto americano de referência global.',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'us500',
    symbol: 'US500',
    name: 'S&P 500 Index',
    type: 'indices',
    category: 'indices',
    exchange: 'CBOE',
    is_active: true,
    last_price: 5520.40,
    price_change_percent_24h: 0.54,
    high_24h: 5545.00,
    low_24h: 5490.10,
    volume_24h: 18500000000,
    base_currency: 'SPX',
    quote_currency: 'USD',
    min_order_size: 0.1,
    max_leverage: 50,
    precision: 2,
    description: 'Índice das 500 maiores empresas dos Estados Unidos.',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },

  // STOCKS
  {
    id: 'tsla-usd',
    symbol: 'TSLA',
    name: 'Tesla Motors',
    type: 'stocks',
    category: 'stocks',
    exchange: 'NASDAQ',
    is_active: true,
    last_price: 218.80,
    price_change_percent_24h: 5.12,
    high_24h: 224.00,
    low_24h: 209.50,
    volume_24h: 1120000000,
    base_currency: 'TSLA',
    quote_currency: 'USD',
    min_order_size: 1,
    max_leverage: 20,
    precision: 2,
    description: 'Líder em veículos elétricos e energia limpa.',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'aapl-usd',
    symbol: 'AAPL',
    name: 'Apple Inc.',
    type: 'stocks',
    category: 'stocks',
    exchange: 'NASDAQ',
    is_active: true,
    last_price: 224.30,
    price_change_percent_24h: 0.88,
    high_24h: 226.10,
    low_24h: 222.00,
    volume_24h: 890000000,
    base_currency: 'AAPL',
    quote_currency: 'USD',
    min_order_size: 1,
    max_leverage: 20,
    precision: 2,
    description: 'Gigante de tecnologia de consumo e hardware.',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'nvda-usd',
    symbol: 'NVDA',
    name: 'NVIDIA Corp',
    type: 'stocks',
    category: 'stocks',
    exchange: 'NASDAQ',
    is_active: true,
    last_price: 122.50,
    price_change_percent_24h: 6.45,
    high_24h: 125.00,
    low_24h: 116.80,
    volume_24h: 3100000000,
    base_currency: 'NVDA',
    quote_currency: 'USD',
    min_order_size: 1,
    max_leverage: 20,
    precision: 2,
    description: 'Líder global em semicondutores e hardware para Inteligência Artificial.',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  }
];

// Gerador Realista de Velas OHLCV para Gráficos Profissionais
export function generateCandlesForAsset(
  basePrice: number,
  timeframe: string = '4h',
  count: number = 60
): Candle[] {
  const candles: Candle[] = [];
  let currentPrice = basePrice * 0.92; // começa 8% atrás para criar tendência histórica
  const now = Date.now();
  
  // Duração em ms
  const timeframeMsMap: Record<string, number> = {
    '1m': 60 * 1000,
    '5m': 5 * 60 * 1000,
    '15m': 15 * 60 * 1000,
    '1h': 60 * 60 * 1000,
    '4h': 4 * 60 * 60 * 1000,
    '1D': 24 * 60 * 60 * 1000,
    '1W': 7 * 24 * 60 * 60 * 1000,
  };

  const stepMs = timeframeMsMap[timeframe] || (4 * 60 * 60 * 1000);
  const startTime = now - count * stepMs;

  let trend = 0.0008; // viés de alta leve
  const volatility = basePrice > 1000 ? 0.008 : basePrice > 100 ? 0.012 : 0.004;

  for (let i = 0; i < count; i++) {
    const timeMs = startTime + i * stepMs;
    const dateObj = new Date(timeMs);
    const dateStr = timeframe === '1D' || timeframe === '1W'
      ? dateObj.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })
      : dateObj.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

    // Alterna micro-tendências a cada 8-12 velas
    if (i % 10 === 0) {
      trend = (Math.random() - 0.48) * 0.003;
    }

    const changePercent = (Math.random() - 0.49) * volatility + trend;
    const open = currentPrice;
    let close = open * (1 + changePercent);

    // Se for a última vela, garante que termine perto do basePrice atual
    if (i === count - 1) {
      close = basePrice;
    }

    const high = Math.max(open, close) * (1 + Math.random() * volatility * 0.6);
    const low = Math.min(open, close) * (1 - Math.random() * volatility * 0.6);
    const volume = Math.round((Math.random() * 0.8 + 0.4) * (basePrice * 120));

    candles.push({
      time: dateStr,
      timestamp: timeMs,
      open: Number(open.toFixed(basePrice > 100 ? 2 : 4)),
      high: Number(high.toFixed(basePrice > 100 ? 2 : 4)),
      low: Number(low.toFixed(basePrice > 100 ? 2 : 4)),
      close: Number(close.toFixed(basePrice > 100 ? 2 : 4)),
      volume,
    });

    currentPrice = close;
  }

  return candles;
}

// Gerador de Livro de Ofertas (Orderbook Depth estilo Bybit/Binance)
export function generateOrderBook(currentPrice: number, precision: number = 2): OrderBookData {
  const step = currentPrice * 0.0012;
  const asks: OrderBookItem[] = [];
  const bids: OrderBookItem[] = [];

  let askCum = 0;
  for (let i = 1; i <= 8; i++) {
    const price = Number((currentPrice + i * step).toFixed(precision));
    const amount = Number((Math.random() * 2.5 + 0.2).toFixed(3));
    askCum += amount;
    asks.unshift({ price, amount, total: Number(askCum.toFixed(3)) });
  }

  let bidCum = 0;
  for (let i = 1; i <= 8; i++) {
    const price = Number((currentPrice - i * step).toFixed(precision));
    const amount = Number((Math.random() * 2.5 + 0.2).toFixed(3));
    bidCum += amount;
    bids.push({ price, amount, total: Number(bidCum.toFixed(3)) });
  }

  const spread = Number((asks[asks.length - 1].price - bids[0].price).toFixed(precision));

  return { asks, bids, spread };
}

// Desafios Interativos de Padrões Gráficos (Quiz & Treinamento)
export interface PatternQuizItem {
  id: string;
  title: string;
  difficulty: 'Iniciante' | 'Intermediário' | 'Avançado';
  category: 'Candlestick' | 'Análise Técnica' | 'Gestão de Risco' | 'Smart Money';
  question: string;
  patternName: string;
  candlesSnippet: { open: number; high: number; low: number; close: number; time: string }[];
  options: string[];
  correctIndex: number;
  explanation: string;
  traderTip: string;
  xpReward: number;
}

export const PATTERN_QUIZ_DATABASE: PatternQuizItem[] = [
  {
    id: 'quiz-1',
    title: 'Identificação de Engenfo de Alta (Bullish Engulfing)',
    difficulty: 'Iniciante',
    category: 'Candlestick',
    question: 'Observe a formação das últimas duas velas em zona de suporte. Qual a interpretação técnica mais provável e a ação recomendada?',
    patternName: 'Engolfo de Alta',
    candlesSnippet: [
      { open: 100, high: 101, low: 96, close: 97, time: 'Vela 1' },
      { open: 96.5, high: 103, low: 96, close: 102.5, time: 'Vela 2' }
    ],
    options: [
      'Sinal de continuação de baixa; abrir posição VENDIDA (Short).',
      'Reversão altista confirmada; abrir posição COMPRADA (Long) no fechamento com Stop Loss abaixo da mínima.',
      'Mercado lateral indeciso; aguardar quebra do suporte.',
      'Exaustão de compradores; colocar ordem de venda com stop no topo.'
    ],
    correctIndex: 1,
    explanation: 'O Engolfo de Alta ocorre quando o corpo da segunda vela verde cobre completamente o corpo da vela vermelha anterior. Em uma zona de suporte, indica forte entrada de pressão compradora.',
    traderTip: 'Dica Pro: Só opere Engolfos quando eles se formarem em níveis chave de Suporte ou Suporte Fibonacci (0.618), nunca no meio do gráfico!',
    xpReward: 150
  },
  {
    id: 'quiz-2',
    title: 'Reconhecimento de Martelo (Hammer Pin Bar)',
    difficulty: 'Iniciante',
    category: 'Candlestick',
    question: 'Uma vela com pavio inferior longo (3x o tamanho do corpo) se forma após uma tendência de queda. O que o pavio representa?',
    patternName: 'Martelo / Pin Bar',
    candlesSnippet: [
      { open: 150, high: 151, low: 135, close: 149.5, time: 'Martelo' }
    ],
    options: [
      'Rejeição forte de preços mais baixos pelos compradores e absorção de oferta.',
      'Sinal claro de que os vendedores continuam no controle absoluto.',
      'Falta de volume no mercado.',
      'Erro no feed de dados da corretora.'
    ],
    correctIndex: 0,
    explanation: 'O pavio inferior longo demonstra que os vendedores tentaram empurrar o preço para baixo, mas foram fortemente superados pelos compradores antes do fechamento.',
    traderTip: 'Pro Tip: O Stop Loss correto para uma operação de Martelo fica 2-3 pips abaixo da sombra/pavio inferior.',
    xpReward: 150
  },
  {
    id: 'quiz-3',
    title: 'Padrão Ombro-Cabeça-Ombro (OCO / Head & Shoulders)',
    difficulty: 'Intermediário',
    category: 'Análise Técnica',
    question: 'O gráfico formou três topos, onde o do meio é o mais alto. O preço acabou de romper a "Linha de Pescoço" (Neckline) para baixo com alto volume. Qual a meta de projeção?',
    patternName: 'Ombro-Cabeça-Ombro',
    candlesSnippet: [
      { open: 200, high: 220, low: 195, close: 205, time: 'Ombro E' },
      { open: 205, high: 240, low: 195, close: 200, time: 'Cabeça' },
      { open: 200, high: 220, low: 195, close: 190, time: 'Ombro D' }
    ],
    options: [
      'Projeta-se a distância entre a Cabeça e a Linha de Pescoço para baixo a partir do ponto de rompimento.',
      'O mercado subirá para testar a máxima da cabeça imediatamente.',
      'A meta é sempre 10% abaixo do preço atual.',
      'O padrão OCO é inválido se não houver notícias macroeconómicas.'
    ],
    correctIndex: 0,
    explanation: 'A projeção alvo do Ombro-Cabeça-Ombro é obtida medindo a altura vertical entre o topo da Cabeça e a Linha de Pescoço, projetando essa mesma distância para baixo.',
    traderTip: 'Aguarde o retest (pullback) na linha de pescoço romCloud para obter um Risco/Retorno (R:R) superior a 1:3!',
    xpReward: 250
  },
  {
    id: 'quiz-4',
    title: 'Cálculo de Gestão de Risco e Tamanho de Lote',
    difficulty: 'Avançado',
    category: 'Gestão de Risco',
    question: 'Sua banca de treino é de $10.000 USDT. Você aceita arriscar no máximo 1% por operação ($100). Seu ponto de entrada é $60.000 no BTC e Stop Loss em $58.800 (distância de 2%). Qual o tamanho correto da posição?',
    patternName: 'Gestão de Capital',
    candlesSnippet: [],
    options: [
      '$5.000 USDT de posição total (sem violar o risco de $100 se atingir o Stop).',
      '$10.000 USDT usando alavancagem 100x.',
      '$500 USDT de posição.',
      '$100 USDT apenas.'
    ],
    correctIndex: 0,
    explanation: 'Risco Máximo = $100. Distância do Stop = 2% (0.02). Tamanho da Posição = Risco / %Stop = $100 / 0.02 = $5.000 USDT. Se o BTC cair 2%, você perde exatamente $100 (1% da banca).',
    traderTip: 'Nunca ajuste a posição pelo sentimento! O cálculo matemático do Stop Loss deve ditar o valor financeiro da ordem.',
    xpReward: 350
  }
];

// Replay Histórico de Cenas Reais do Mercado
export interface HistoricalScenario {
  id: string;
  title: string;
  symbol: string;
  periodName: string;
  difficulty: string;
  description: string;
  initialPrice: number;
  targetPnlPercent: number;
  candles: Candle[];
}

export const HISTORICAL_SCENARIOS: HistoricalScenario[] = [
  {
    id: 'scenario-btc-halving',
    title: 'Rompimento de Alta do Bitcoin (Bull Run Breakout)',
    symbol: 'BTC/USDT',
    periodName: 'Pós-Consolidação de 6 Meses',
    difficulty: 'Médio',
    description: 'O BTC ficou preso entre $60k e $64k por semanas. As médias móveis MA20 e MA50 se cruzaram e o RSI rompeu a linha 50. Pratique identificar o momento certo de entrada!',
    initialPrice: 62400,
    targetPnlPercent: 12.5,
    candles: generateCandlesForAsset(62400, '4h', 40)
  },
  {
    id: 'scenario-gold-rally',
    title: 'Corrida do Ouro para Máxima Histórica',
    symbol: 'XAU/USD',
    periodName: 'Tensão Geopolítica & Queda do Dólar',
    difficulty: 'Fácil',
    description: 'O Ouro retestou a zona de suporte em $2.380 com volume comprador massivo. Encontre o ponto de entrada no Pivot e defina o Risco/Retorno correto.',
    initialPrice: 2385,
    targetPnlPercent: 8.0,
    candles: generateCandlesForAsset(2385, '1h', 45)
  },
  {
    id: 'scenario-eur-ecb',
    title: 'Decisão de Juros do Banco Central Europeu (EUR/USD)',
    symbol: 'EUR/USD',
    periodName: 'Volatilidade de Notícia Macro',
    difficulty: 'Difícil',
    description: 'Alta volatilidade após declaração do BCE. Padrão de topo duplo com divergência de alta/baixa no RSI. Saiba gerenciar Stops em mercados rápidos.',
    initialPrice: 1.0850,
    targetPnlPercent: 5.0,
    candles: generateCandlesForAsset(1.0850, '15m', 50)
  }
];
